import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class TestVine {
    WebDriver driver;
    @BeforeEach
    public void beforeEachFunction(){

        System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.yellowtailwine.com/");

    }

    @AfterEach
    public void after(){
        driver.quit();
    }


    @Test
    public void requiredElementsShowed() throws InterruptedException {




        By legalDrinkAge = By.cssSelector("div.confirmation-checkbox > label");
        By selectCountry = By.cssSelector("#agegate-selector-options");
        By welcomeButton = By.cssSelector("[type=\"submit\"][disabled]");
        Thread.sleep(2000);

    }

    @Test
    public void navigateAsEurope() throws InterruptedException{

        By legalDrinkAge = By.cssSelector("div.confirmation-checkbox > label");
        WebElement checkLegalDrink = driver.findElement(legalDrinkAge);
        checkLegalDrink.click();
        Thread.sleep(2000);

        By selectCountry = By.cssSelector("#agegate-selector-options");
        WebElement chooseCountry = driver.findElement(selectCountry);
        chooseCountry.click();
        Thread.sleep(2000);

        By chooseEurope = By.cssSelector("[value=\"eu\"]");
        WebElement europe = driver.findElement(chooseEurope);
        europe.click();
        Thread.sleep(2000);
        By welcomeButton = By.cssSelector("[type=\"submit\"]");
        WebElement welcomeButtonPush = driver.findElement(welcomeButton);
        welcomeButtonPush.click();

    }

    @Test
    public void menuButtonLogicHeaderOpen() throws InterruptedException{

        By legalDrinkAge = By.cssSelector("div.confirmation-checkbox > label");
        WebElement checkLegalDrink = driver.findElement(legalDrinkAge);
        checkLegalDrink.click();
        Thread.sleep(2000);

        By selectCountry = By.cssSelector("#agegate-selector-options");
        WebElement chooseCountry = driver.findElement(selectCountry);
        chooseCountry.click();
        Thread.sleep(2000);

        By chooseEurope = By.cssSelector("[value=\"eu\"]");
        WebElement europe = driver.findElement(chooseEurope);
        europe.click();
        Thread.sleep(2000);
        By welcomeButton = By.cssSelector("[type=\"submit\"]");
        WebElement welcomeButtonPush = driver.findElement(welcomeButton);
        welcomeButtonPush.click();
        By menuBar = By.cssSelector(".fa.fa-bars");
        WebElement menuBarOpen = driver.findElement(menuBar);
        menuBarOpen.click();
        Thread.sleep(1000);
        By wineLink = By.cssSelector("div.main-nav > div > nav > ul > li:nth-child(1) > a");
        By wereToBuyLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(2) > a");
        By cocktailsLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(3) > a");
        By ourStoryLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(4) > a");
        By faqsLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(5) > a");
        By contactLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(6) > a");
        By globeLink = By.cssSelector("#country-select > a");
        By yellowTail = By.cssSelector("div.top-nav.-active > div.main-nav > div > div > a");
        WebElement yellowTailLogo = driver.findElement(yellowTail);
        yellowTailLogo.click();
        Thread.sleep(1000);
        menuBar = By.cssSelector(".fa.fa-bars");





    }

    @Test
    public void menuButtonLogicHeaderClose() throws InterruptedException{

        By legalDrinkAge = By.cssSelector("div.confirmation-checkbox > label");
        WebElement checkLegalDrink = driver.findElement(legalDrinkAge);
        checkLegalDrink.click();
        Thread.sleep(2000);

        By selectCountry = By.cssSelector("#agegate-selector-options");
        WebElement chooseCountry = driver.findElement(selectCountry);
        chooseCountry.click();
        Thread.sleep(2000);

        By chooseEurope = By.cssSelector("[value=\"eu\"]");
        WebElement europe = driver.findElement(chooseEurope);
        europe.click();
        Thread.sleep(2000);
        By welcomeButton = By.cssSelector("[type=\"submit\"]");
        WebElement welcomeButtonPush = driver.findElement(welcomeButton);
        welcomeButtonPush.click();
        By menuBar = By.cssSelector(".fa.fa-bars");
        WebElement menuBarOpen = driver.findElement(menuBar);
        menuBarOpen.click();
        Thread.sleep(1000);
        By yellowTail = By.cssSelector("div.top-nav.-active > div.main-nav > div > div > a");
        WebElement yellowTailLogo = driver.findElement(yellowTail);
        yellowTailLogo.click();
        Thread.sleep(1000);
        menuBar = By.cssSelector(".fa.fa-bars");


    }

    @Test
    public void WhereToBuyValidZipCode() throws InterruptedException {

        By legalDrinkAge = By.cssSelector("div.confirmation-checkbox > label");
        WebElement checkLegalDrink = driver.findElement(legalDrinkAge);
        checkLegalDrink.click();
        Thread.sleep(2000);

        By selectCountry = By.cssSelector("#agegate-selector-options");
        WebElement chooseCountry = driver.findElement(selectCountry);
        chooseCountry.click();
        Thread.sleep(2000);

        By chooseEurope = By.cssSelector("[value=\"eu\"]");
        WebElement europe = driver.findElement(chooseEurope);
        europe.click();
        Thread.sleep(2000);
        By welcomeButton = By.cssSelector("[type=\"submit\"]");
        WebElement welcomeButtonPush = driver.findElement(welcomeButton);
        welcomeButtonPush.click();
        By menuBar = By.cssSelector(".fa.fa-bars");
        WebElement menuBarOpen = driver.findElement(menuBar);
        menuBarOpen.click();
        Thread.sleep(1000);
        By wereToBuyLink = By.cssSelector(".main-nav > div > nav > ul > li:nth-child(2) > a");
        WebElement wereBuy = driver.findElement(wereToBuyLink);
        wereBuy.click();
        By inputField = By.cssSelector("#locationName");
        WebElement inputElement = driver.findElement(inputField);
        inputElement.click();
        inputElement.sendKeys("Sydney, Australia");
        Thread.sleep(1000);
        inputElement.sendKeys(Keys.ENTER);

        By searchResultSelector = By.cssSelector(".address");

        List<WebElement> searchResult = driver.findElements(searchResultSelector);

        Assertions.assertTrue(searchResult.get(0).getText().contains("Sydney"));






    }

}
