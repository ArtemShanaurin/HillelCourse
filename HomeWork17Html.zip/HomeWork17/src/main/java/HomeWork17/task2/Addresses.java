package HomeWork17.task2;

import com.sun.xml.internal.ws.wsdl.writer.document.http.Address;

public class Addresses extends Person{
    private Address[] address;

    public Address[] getAddress() {
        return address; }
    public void setAddress(Address[] value) {
        this.address = value; }
}
