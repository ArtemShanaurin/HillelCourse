package HomeWork17.task2;

public interface Deserialization {
}
