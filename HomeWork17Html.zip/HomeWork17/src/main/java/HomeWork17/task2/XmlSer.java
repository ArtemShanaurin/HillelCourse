package HomeWork17.task2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import sun.rmi.server.DeserializationChecker;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class XmlSer {
    public static void main(String[] args) throws JsonProcessingException {
        XmlMapper xmlMapper = new XmlMapper();
        String fileName = "Hometask.xml";
        ClassLoader classLoader = Deserialization.class.getClassLoader();
        File fileNew = new File(classLoader.getResource(fileName).getFile());
        String absolutePath = fileNew.getAbsolutePath();

        Path file = Paths.get(absolutePath);

        String data1 = "<Person><firstName>Rohan</firstName> <lastName>Daye</lastName> <phoneNumbers><phoneNumbers>9911034731</phoneNumbers><phoneNumbers>9911033478</phoneNumbers></phoneNumbers>";
        Person data = xmlMapper.readValue(data1, Person.class);

        System.out.println(data);
    }
}
