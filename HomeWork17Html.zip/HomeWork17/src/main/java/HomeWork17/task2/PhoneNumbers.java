package HomeWork17.task2;

public class PhoneNumbers extends Person {
    private String[] phoneNumbers;

    public String[] getPhoneNumbers() { return phoneNumbers; }
    public void setPhoneNumbers(String[] value) { this.phoneNumbers = value; }
}
