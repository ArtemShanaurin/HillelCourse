package HomeWork17.task2;

public class Person {
    private String firstName;
    private String lastName;
    private String[] phoneNumbers;
    private Addresses addresses;

    public String getFirstName() { return firstName; }
    public void setFirstName(String value) { this.firstName = value; }

    public String getLastName() { return lastName; }
    public void setLastName(String value) { this.lastName = value; }

    public String[] getPhoneNumbers() { return phoneNumbers; }
    public void setPhoneNumbers(String[] value) { this.phoneNumbers = value; }

    public Addresses getAddresses() { return addresses; }
    public void setAddresses(Addresses value) { this.addresses = value; }
}
