package HomeWork17.task1;

public class Properties {
}
