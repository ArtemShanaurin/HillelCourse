package HomeWork17.task1;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.InvalidPathException;


public class JsonSer {
    public static void main(String[] args) throws IOException, InvalidPathException {
        ObjectMapper objectMapper = new ObjectMapper();


        String jsonNewList =
                "{ \"type\" : \"type\", \"properties\" : \"properties\"}";
        JsonExample jsonNew = objectMapper.readValue(jsonNewList, JsonExample.class);
        System.out.println("New object:"+jsonNew);


    }
}
